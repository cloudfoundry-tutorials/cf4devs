#!/bin/bash

now=$(date +"%T")
echo "It is ${now}. Do you know where your containers are?"