# Sample app

This is a sample application written in Go used for training purposes.

