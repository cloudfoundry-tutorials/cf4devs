#!/bin/bash

set -e

mv rc-app/*.zip artifact/sample-app.zip
mv rc-manifest/*.yml artifact/manifest.yml
