#!/bin/bash

pushd source 
  go test
popd